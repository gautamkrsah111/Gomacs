#!/usr/bin/env python3
import subprocess
import os
import sys

def check_file(filename, critical=True):
    """Check if file exists; if critical and missing, abort the script."""
    if not os.path.isfile(filename):
        print(f"Critical Error: File '{filename}' does not exist.")
        if critical:
            print("Aborting further steps.")
            sys.exit(1)
        return False
    return True

def run_command(command, auto=True, input_data=None, description=""):
    """
    Executes a command and prints status messages.
    If auto is True and input_data is provided, input is piped.
    Otherwise, the command runs interactively.
    Returns the command's return code.
    """
    print("\n--------------------------------------------")
    print(f"STEP: {description}")
    print(f"Command: {' '.join(command)}")
    try:
        if auto and input_data is not None:
            result = subprocess.run(command, input=input_data, text=True)
        else:
            result = subprocess.run(command)
        if result.returncode != 0:
            print(f"WARNING: Command exited with code {result.returncode}")
        return result.returncode
    except Exception as e:
        print(f"Error running command: {e}")
        return -1

def create_minimal_lig_itp():
    """
    If lig.itp is missing, create a minimal ligand topology file
    with the basic [ moleculetype ] definition.
    """
    if not os.path.isfile("LIG.itp"):                #--------------------------------------------------Further modication needed.....for special cases
        print("\n--------------------------------------------")
        print("lig.itp not found. Creating a minimal 'lig.itp' file.")
        minimal_content = (
            "[ moleculetype ]\n"
            "; Name            nrexcl\n"
            "LIG 3\n\n"
            "[ atoms ]\n"
            "; This file was auto-generated. Please verify the ligand atom definitions.\n"
        )
        try:
            with open("LIG.itp", "w") as f:
                f.write(minimal_content)
            print("Minimal lig.itp created.")
        except Exception as e:
            print(f"Error creating lig.itp: {e}")
            sys.exit(1)
    else:
        print("LIG.itp exists. Proceeding with modification if needed.")

def modify_conf_gro():
    """
    Opens LIG.gro and copies its content from the 3rd line up to the 2nd last line.
    Then opens conf.gro, pastes those lines just before the last line, and
    updates the second line of conf.gro to be (final total lines - 3).
    """
    print("\n--------------------------------------------")
    print("Modifying conf.gro by merging in LIG.gro data...")
    try:
        with open('LIG.gro', 'r') as f:
            lig_lines = f.readlines()
    except Exception as e:
        print(f"Error opening LIG.gro: {e}")
        return

    if len(lig_lines) < 3:
        print("Error: LIG.gro does not have enough lines to perform the merge.")
        return

    # Copy from 3rd line (index 2) to second last line
    lig_copy = lig_lines[2:-1]

    try:
        with open('conf.gro', 'r') as f:
            conf_lines = f.readlines()
    except Exception as e:
        print(f"Error opening conf.gro: {e}")
        return

    if len(conf_lines) < 2:
        print("Error: conf.gro does not have the required structure (at least two lines).")
        return

    # Insert the LIG block before the last line
    new_conf = conf_lines[:-1] + lig_copy + [conf_lines[-1]]
    # Update second line: (total lines - 3)
    total_lines = len(new_conf)
    new_conf[1] = f"{total_lines - 3}\n"

    try:
        with open('conf.gro', 'w') as f:
            f.writelines(new_conf)
        print("conf.gro modified successfully.")
    except Exception as e:
        print(f"Error writing conf.gro: {e}")

def modify_topol_top():
    """
    In topol.top, find the first occurrence of:
        ; Include forcefield parameters
        #include "amberGS.ff/forcefield.itp"
    and immediately insert:
        ; Include ligand topology 
        #include "LIG.itp"
    Then append "LIG                 1" at the very end.
    """
    print("\n--------------------------------------------")
    print("Modifying topol.top for ligand topology...")
    try:
        with open('topol.top', 'r') as f:
            lines = f.readlines()
    except Exception as e:
        print(f"Error opening topol.top: {e}")
        return

    new_lines = []
    inserted_topology = False
    flag = False
    i = 0
    while i < len(lines):
        new_lines.append(lines[i])
        if (flag==True):
            new_lines.append("\n; Include ligand topology \n#include \"LIG.itp\"\n")
            flag = False
        if (not inserted_topology and 
            "; Include forcefield parameters" in lines[i] and 
            i + 1 < len(lines)):
            inserted_topology = True
            flag = True
        i += 1
    new_lines.append("LIG                 1\n")

    try:
        with open('topol.top', 'w') as f:
            f.writelines(new_lines)
        print("topol.top modified successfully (ligand topology added).")
    except Exception as e:
        print(f"Error writing topol.top: {e}")

def modify_lig_itp():
    """
    In lig.itp, if present, replace "lig_gmx2 3" with "LIG 3". If not present,
    the file is assumed already updated.
    """
    print("\n--------------------------------------------")
    print("Modifying lig.itp for molecule type...")
    if not os.path.isfile("LIG.itp"):
        print("lig.itp not found (should have been created already). Skipping modification.")
        return

    try:
        with open('LIG.itp', 'r') as f:
            lines = f.readlines()
    except Exception as e:
        print(f"Error opening lig.itp: {e}")
        return

    modified = False
    new_lines = []
    for line in lines:
        if "lig_gmx2 3" in line:
            new_lines.append(line.replace("lig_gmx2 3", "LIG 3"))
            modified = True
        else:
            new_lines.append(line)

    if modified:
        try:
            with open('LIG.itp', 'w') as f:
                f.writelines(new_lines)
            print("lig.itp modified successfully (molecule type updated).")
        except Exception as e:
            print(f"Error writing lig.itp: {e}")
    else:
        print("lig.itp modification not needed (already updated).")

def modify_topol_top_posres():
    """
    In topol.top, locate the block:
        ; Include Position restraint file
        #ifdef POSRES
        #include "posre.itp"
        #endif
    and immediately after insert:
        ; Ligand position restraints
        #ifdef POSRES
        #include "posre_LIG.itp"
        #endif
    """
    print("\n--------------------------------------------")
    print("Modifying topol.top for ligand position restraints...")
    try:
        with open('topol.top', 'r') as f:
            lines = f.readlines()
    except Exception as e:
        print(f"Error opening topol.top: {e}")
        return

    new_lines = []
    inserted = False
    i = 0
    while i < len(lines):
        new_lines.append(lines[i])
        if not inserted and "; Include Position restraint file" in lines[i]:
            i += 1
            while i < len(lines):
                new_lines.append(lines[i])
                if "#endif" in lines[i]:
                    # Insert the ligand restraints block immediately after the block
                    new_lines.append("\n; Ligand position restraints\n#ifdef POSRES\n#include \"posre_LIG.itp\"\n#endif\n")
                    inserted = True
                    i += 1
                    break
                i += 1
            continue
        i += 1
    #if not inserted:
    #new_lines.append("\n; Ligand position restraints\n#ifdef POSRES\n#include \"posre_LIG.itp\"\n#endif\n")

    try:
        with open('topol.top', 'w') as f:
            f.writelines(new_lines)
        print("topol.top modified successfully (position restraints added).")
    except Exception as e:
        print(f"Error writing topol.top:$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ {e}")

def modify_md_mdp(sim_time_ns):
    """
    Updates MD.mdp with the simulation time provided by the user.
    Searches for a line starting with 'nsteps' and updates it.
    Conversion: nsteps = (sim_time_ns * 1000) / 0.002
    """
    print("\n--------------------------------------------")
    print("Modifying MD.mdp for simulation time...")
    try:
        with open('MD.mdp', 'r') as f:
            lines = f.readlines()
    except Exception as e:
        print(f"Error opening MD.mdp: {e}")
        return

    dt = 0.002  # in ps
    try:
        nsteps = int(sim_time_ns * 1000 / dt)
    except Exception as e:
        print(f"Error computing nsteps: {e}")
        return

    new_lines = []
    updated = False
    for line in lines:
        if line.strip().startswith("nsteps"):
            parts = line.split(";")
            new_line = f"nsteps                  = {nsteps}"
            if len(parts) > 1:
                new_line += " ;" + parts[1]
            new_line += "\n"
            new_lines.append(new_line)
            updated = True
        else:
            new_lines.append(line)

    if not updated:
        print("Warning: 'nsteps' line not found in MD.mdp. No changes made.")
    else:
        try:
            with open('MD.mdp', 'w') as f:
                f.writelines(new_lines)
            print("MD.mdp modified successfully with new simulation time.")
        except Exception as e:
            print(f"Error writing MD.mdp: {e}")

def modify_sim_time(file_name):
    try:
        with open (file_name, 'r') as  f:
            lines = f.readlines()
    except Exception as e:
        print(f"Error opening NVT/NPT.mdp files: {e}")
        return
    new_lines = []    
    for line in lines:
        flag = False
        if line.strip().startswith("nsteps"):
            new_lines.append("nsteps                  = 2500   ; (500->1ps)\n")
            flag = True
            status = "success"
        if (flag!=True):
            new_lines.append(line)
    try:
        with open (file_name, 'w') as g:
            g.writelines(new_lines)
            if (status == "success"):
                print (f"Number of steps Has been successfully modified in {file_name} to 5ps")
    except Exception as e:
            print(f"Error writing {file_name}: {e}")

def main():
    print("GROMACS Ubuntu Tutorial Automation Script")
    #mode = input("Select automation mode ('auto' for default responses, 'manual' for interactive): ").strip().lower()
    #auto_mode = (mode == "auto")
    auto_mode = True


    # Step 1: gmx pdb2gmx
    run_command(["gmx", "pdb2gmx", "-f", "REC.pdb", "-ignh"],
                auto=auto_mode, 
                input_data="8\n1\n" if auto_mode else None,
                description="pdb2gmx (select CHARMM27=8 and TIP3P=1)")
    # Check for expected output files if needed here

    # Step 2: gmx editconf to generate LIG.gro from LIG.pdb
    run_command(["gmx", "editconf", "-f", "LIG.pdb", "-o", "LIG.gro"],
                auto=auto_mode,
                description="editconf (LIG.pdb to LIG.gro)")
    check_file("LIG.gro")

    # Step 3: Merge LIG.gro into conf.gro (automatic file editing)
    check_file("conf.gro")
    modify_conf_gro()
    check_file("conf.gro")

    # Step 4: Modify topol.top to add ligand topology
    check_file("topol.top")
    modify_topol_top()
    check_file("topol.top")

    # Step 5: Modify lig.itp (update molecule type)
    create_minimal_lig_itp()
    modify_lig_itp()
    check_file("LIG.itp")

    # Step 6: gmx editconf to generate box.gro from conf.gro
    run_command(["gmx", "editconf", "-f", "conf.gro", "-d", "1.0", "-bt", "triclinic", "-o", "box.gro"],
                auto=auto_mode,
                description="editconf (conf.gro to box.gro)")
    check_file("box.gro")

    # Step 7: gmx solvate to generate box_sol.gro
    run_command(["gmx", "solvate", "-cp", "box.gro", "-cs", "spc216.gro", "-p", "topol.top", "-o", "box_sol.gro"],
                auto=auto_mode,
                description="solvate (box.gro)")
    check_file("box_sol.gro")

    # Step 8: gmx grompp for ions – first try without -maxwarn
    ret = run_command(["gmx", "grompp", "-f", "ions.mdp", "-c", "box_sol.gro", "-maxwarn", "2",
                           "-p", "topol.top", "-o", "ION.tpr"],
                      auto=auto_mode,
                      description="grompp for ions (attempt with* -maxwarn)")
    if ret != 0:
        print("Retrying grompp for ions with -maxwarn 2...")
        ret = run_command(["gmx", "grompp", "-f", "ions.mdp", "-c", "box_sol.gro", "-p", "topol.top", "-o", "ION.tpr"],
                          auto=auto_mode,
                          description="grompp for ions (without -maxwarn 2)")
    check_file("ION.tpr")

    # Step 9: gmx genion
    ret = run_command(["gmx", "genion", "-s", "ION.tpr", "-p", "topol.top",
                       "-conc", "0.1", "-neutral", "-o", "box_sol_ion.gro"],
                      auto=auto_mode,
                      input_data="15\n" if auto_mode else None,
                      description="genion (default selection '15')")
    check_file("box_sol_ion.gro")

    # Step 10: gmx grompp for EM – try without -maxwarn first
    ret = run_command(["gmx", "grompp", "-f", "EM.mdp", "-c", "box_sol_ion.gro",
                           "-maxwarn", "2", "-p", "topol.top", "-o", "EM.tpr"],
                      auto=auto_mode,
                      description="grompp for EM (attempt with* -maxwarn)")
    if ret != 0:
        print("Retrying grompp for EM with -maxwarn 2...")
        ret = run_command(["gmx", "grompp", "-f", "EM.mdp", "-c", "box_sol_ion.gro",
                       "-p", "topol.top", "-o", "EM.tpr"],
                          auto=auto_mode,
                          description="grompp for EM (with -maxwarn 2)")
    check_file("EM.tpr")

    # Step 11: gmx mdrun for EM
    ret = run_command(["gmx", "mdrun", "-v", "-deffnm", "EM"],
                      auto=auto_mode,
                      description="mdrun for EM")
    # Expected output: EM.gro should be generated
    check_file("EM.gro")
    
    #STEP 11.5 GEDIT NVT.MDP **************************************************************************************************************
    # Step 11.555555: Modify NVT.mdp for simulation time
    modify_sim_time("NVT.mdp")
    check_file("NVT.mdp")
    
    # Step 12: Make index file for ligand (index_LIG.ndx)
    ret = run_command(["gmx", "make_ndx", "-f", "LIG.gro", "-o", "index_LIG.ndx"],
                      auto=auto_mode,
                      input_data="0 & ! a H*\nq\n" if auto_mode else None,
                      description="make_ndx for LIG (index_LIG.ndx)")
    check_file("index_LIG.ndx")

    # Step 13: Generate ligand position restraints file (posre_LIG.itp)
    ret = run_command(["gmx", "genrestr", "-f", "LIG.gro", "-n", "index_LIG.ndx",
                       "-o", "posre_LIG.itp", "-fc", "1000", "1000", "1000"],
                      auto=auto_mode,
                      input_data="3\n" if auto_mode else None,
                      description="genrestr for LIG (posre_LIG.itp)")
    check_file("posre_LIG.itp")

    # Step 14: Modify topol.top to add ligand position restraints block
    modify_topol_top_posres()
    check_file("topol.top")

    # Step 15: Make index file for system (index.ndx)
    ret = run_command(["gmx", "make_ndx", "-f", "EM.gro", "-o", "index.ndx"],
                      auto=auto_mode,
                      input_data="1 | 13\nq\n" if auto_mode else None,
                      description="make_ndx for system (index.ndx)")
    check_file("index.ndx")

    # Step 15.5555555: Modify NVT.mdp for simulation time
    modify_sim_time("NVT.mdp")
    check_file("NVT.mdp")
    
    # Step 16: grompp for NVT equilibration
    ret = run_command(["gmx", "grompp", "-f", "NVT.mdp", "-c", "EM.gro", "-r", "EM.gro",
                       "-p", "topol.top", "-n", "index.ndx", "-maxwarn", "2", "-o", "NVT.tpr"],
                      auto=auto_mode,
                      description="grompp for NVT equilibration")
    #check_file("NVT.tpr")

    # Step 17: mdrun for NVT equilibration
    run_command(["gmx", "mdrun", "-deffnm", "NVT"],
                auto=auto_mode,
                description="mdrun for NVT equilibration")
    check_file("NVT.gro")

    # Step 17.5555555: Modify NPT.mdp for simulation time
    modify_sim_time("NPT.mdp")
    check_file("NPT.mdp")

    # Step 18: grompp for NPT equilibration
    ret = run_command(["gmx", "grompp", "-f", "NPT.mdp", "-c", "NVT.gro", "-r", "NVT.gro",
                       "-p", "topol.top", "-n", "index.ndx", "-maxwarn", "2", "-o", "NPT.tpr"],
                      auto=auto_mode,
                      description="grompp for NPT equilibration")
    check_file("NPT.tpr")

    # Step 19: mdrun for NPT equilibration
    run_command(["gmx", "mdrun", "-deffnm", "NPT"],
                auto=auto_mode,
                description="mdrun for NPT equilibration")
    check_file("NPT.gro")


    # Step 20: Modify MD.mdp for simulation time
    try:
        #sim_time_ns = float(input("\nEnter desired simulation time in nanoseconds (ns): "))
        sim_time_ns = 0.005
    except Exception as e:
        print(f"Invalid input, defaulting to 10 ns. Error: {e}")
        sim_time_ns = 0.005
    modify_md_mdp(sim_time_ns)
    check_file("MD.mdp")

    # Step 21: grompp for MD production
    ret = run_command(["gmx", "grompp", "-f", "MD.mdp", "-c", "NPT.gro", "-t", "NPT.cpt",
                       "-p", "topol.top", "-n", "index.ndx", "-maxwarn", "2", "-o", "MD.tpr"],
                      auto=auto_mode,
                      description="grompp for MD production")
    check_file("MD.tpr")

    # Step 22: mdrun for MD production
    run_command(["gmx", "mdrun", "-deffnm", "MD"],
                auto=auto_mode,
                description="mdrun for MD production")
    check_file("MD.gro")

    print("\n============================================")
    print("All steps completed successfully.")

if __name__ == "__main__":
    main()

